#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int substring(char *, char *);
int main(int argc, char *argv[]) {
	FILE *fp;
	char *str, *ch;
	int i;
	str = (char *)malloc(1000);
	if(argc == 3) {
		fp = fopen(argv[2], "r");
		while(fgets(str, 1000, fp)) {
			ch = strchr(str, '\n');
			ch++;
			*ch = '\0';
			i = substring(str, argv[1]);
			if(i == 1) {
				printf("%s", str);
			}
		}
	}
	free(str);
	return 0;
}
int substring(char *str, char *pattern) {
	int i, j, k, flag = 0, max, size_str, size_pattern;
	size_str = strlen(str);
	size_pattern = strlen(pattern);
	max = size_str - size_pattern + 1;
	printf("%s\n", str);
	for(i = 0; i < max; i++) {
		flag = 0;
		for(j = i,k=0; j < (i + size_pattern); j++,k++) {
				if(str[j] == pattern[k]) {
					flag++;
				}
				else {
					flag = 0;
					break;
				}
		}
		if(flag == size_pattern) {
			return 1;
		}
		else {
			return 0;
		}
	}
	return 0;
}
